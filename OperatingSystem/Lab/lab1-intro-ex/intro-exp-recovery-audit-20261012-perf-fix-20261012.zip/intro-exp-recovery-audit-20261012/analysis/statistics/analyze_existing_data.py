#!/usr/bin/env python3
"""Analyze saved CSV files only. No experiment program is executed."""

import argparse
import csv
import hashlib
import html
import json
import math
import re
import statistics
from collections import defaultdict
from datetime import datetime
from pathlib import Path


APIS = ("read_lseek", "mmap")
MODES = ("read", "write")
COLORS = {"read": "#2563A6", "write": "#C24E30"}
RESOURCE_FIELDS = ("user_s", "sys_s", "vol_ctx", "invol_ctx", "minflt", "majflt")
CLOCK_STATUS = "clock_disagreement_logged;monotonic_validity_not_independently_verified"


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def resolve_run_directory(root, value):
    requested = Path(value).expanduser()
    if requested.is_absolute():
        return requested
    direct = root / requested
    return direct if direct.is_dir() else root / "data" / requested


def input_key(root, path):
    try:
        return str(path.relative_to(root))
    except ValueError:
        return str(path)


def read_diagnostic_input(directory, args):
    measurements = directory / "measurements.csv"
    load_path = directory / "load.csv"
    if measurements.exists():
        loads = read_csv(load_path)
        if any("api" not in row for row in loads):
            raise ValueError("Modern load.csv requires an api column")
        return read_csv(measurements), loads, [measurements, load_path], {
            "schema": "modern", "individual_clock_pairs_available": True,
            "record_validation": "saved_valid_and_exit_code_fields",
        }
    tools_path = directory / "tool_overhead.csv"
    if not tools_path.exists() or not load_path.exists():
        raise ValueError("Diagnostic directory requires measurements.csv or legacy tool_overhead.csv plus load.csv")
    source_tools = read_csv(tools_path)
    loads = read_csv(load_path)
    if not args.load_api and any("api" not in row for row in loads):
        raise ValueError("Legacy load.csv has no api column; specify --load-api read_lseek or --load-api mmap")
    rows = []
    for row in source_tools:
        if not math.isfinite(float(row["wall_s"])) or float(row["wall_s"]) <= 0:
            raise ValueError("Invalid legacy tool duration")
        rows.append({**row, "phase": "tools", "mode": "read", "schema": "legacy",
                     "iterations": str(args.trace_iterations)})
    normalized_loads = []
    for row in loads:
        api = row.get("api") or args.load_api
        if api not in APIS or row["condition"] not in ("quiet", "stress"):
            raise ValueError("Invalid legacy load API or condition")
        if not math.isfinite(float(row["wall_s"])) or float(row["wall_s"]) <= 0:
            raise ValueError("Invalid legacy load duration")
        normalized = {**row, "api": api, "iterations": row.get("iterations") or str(args.load_iterations)}
        normalized_loads.append(normalized)
        rows.append({**normalized, "phase": row["condition"], "mode": "read",
                     "tool": "resource", "schema": "legacy"})
    a_files = sorted(str(path.relative_to(directory)) for path in (directory / "A").rglob("*") if path.is_file())
    return rows, normalized_loads, [tools_path, load_path], {
        "schema": "legacy", "mode_B": "read_from_preserved_protocol",
        "trace_iterations_from_cli": args.trace_iterations, "load_iterations_from_cli": args.load_iterations,
        "load_api_from_cli_if_missing": args.load_api,
        "record_validation": "legacy_CSV_lacks_per_run_exit_node_and_clock_validation",
        "individual_clock_pairs_available": False,
        "A_files": a_files, "A_file_count": len(a_files), "A_measurements_synthesized": False,
        "load_protocol": "historical_CPU_IO_memory;verify_saved_script",
    }


def write_csv(path, rows):
    if not rows:
        raise ValueError("Cannot write an empty result table")
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def beta_fraction(a, b, x):
    # Continued fraction for the regularized incomplete beta function.
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    tiny = 1e-300
    c = 1.0
    d = 1.0 - qab * x / qap
    d = tiny if abs(d) < tiny else d
    d = 1.0 / d
    value = d
    for step in range(1, 401):
        twice = 2 * step
        aa = step * (b - step) * x / ((qam + twice) * (a + twice))
        d = 1.0 + aa * d
        d = tiny if abs(d) < tiny else d
        c = 1.0 + aa / c
        c = tiny if abs(c) < tiny else c
        d = 1.0 / d
        value *= d * c
        aa = -(a + step) * (qab + step) * x / ((a + twice) * (qap + twice))
        d = 1.0 + aa * d
        d = tiny if abs(d) < tiny else d
        c = 1.0 + aa / c
        c = tiny if abs(c) < tiny else c
        d = 1.0 / d
        delta = d * c
        value *= delta
        if abs(delta - 1.0) < 3e-14:
            return value
    raise ArithmeticError("Incomplete beta calculation did not converge")


def regularized_beta(x, a, b):
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    factor = math.exp(math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
                      + a * math.log(x) + b * math.log1p(-x))
    if x < (a + 1.0) / (a + b + 2.0):
        return factor * beta_fraction(a, b, x) / a
    return 1.0 - factor * beta_fraction(b, a, 1.0 - x) / b


def student_cdf(value, df):
    beta = regularized_beta(df / (df + value * value), df / 2.0, 0.5)
    return 1.0 - 0.5 * beta if value >= 0 else 0.5 * beta


def student_quantile(df, probability=0.975):
    if df < 1 or not 0.5 < probability < 1.0:
        raise ValueError("Invalid Student t quantile arguments")
    low, high = 0.0, 1.0
    while student_cdf(high, df) < probability:
        high *= 2.0
    for _ in range(80):
        middle = (low + high) / 2.0
        if student_cdf(middle, df) < probability:
            low = middle
        else:
            high = middle
    return (low + high) / 2.0


def describe(values):
    if len(values) < 2 or any(not math.isfinite(value) for value in values):
        raise ValueError("At least two finite observations are required")
    n = len(values)
    mean, sd = statistics.mean(values), statistics.stdev(values)
    se = sd / math.sqrt(n)
    critical = student_quantile(n - 1)
    halfwidth = critical * se
    quartiles = statistics.quantiles(values, n=4, method="inclusive")
    q1, q3 = quartiles[0], quartiles[2]
    iqr = q3 - q1
    return {
        "n": n, "mean": mean, "sample_sd": sd, "standard_error": se,
        "t_critical_95": critical, "ci95_low": mean - halfwidth,
        "ci95_high": mean + halfwidth, "ci95_halfwidth": halfwidth,
        "relative_halfwidth_pct": 100 * halfwidth / abs(mean) if mean else None,
        "median": statistics.median(values), "q1": q1, "q3": q3, "iqr": iqr,
        "min": min(values), "max": max(values),
        "iqr_flagged_retained": sum(value < q1 - 1.5 * iqr or value > q3 + 1.5 * iqr
                                    for value in values),
    }


def estimated_n(sd, target):
    if target <= 0:
        raise ValueError("The precision target must be positive")
    initial = max(2, math.ceil((1.959963984540054 * sd / target) ** 2))
    n = initial
    while student_quantile(n - 1) * sd / math.sqrt(n) > target:
        n += 1
    return initial, n


def snapshot_date(path):
    if not path.exists():
        return None
    match = re.search(r"date=([^\s]+)", path.read_text(encoding="utf-8", errors="replace"))
    return datetime.fromisoformat(match.group(1)) if match else None


def audit_clocks(data_root, output, extra_series=(), extra_diagnostics=()):
    # Read saved logs only; never change source scripts or measurement records.
    output.mkdir(parents=True, exist_ok=True)
    pattern = re.compile(r"CLOCK realtime_s=([0-9.e+-]+) monotonic_s=([0-9.e+-]+)")
    summary = {}
    series_bases = sorted(set(data_root.glob("series-*")) | set(extra_series))
    diagnostic_bases = sorted(set(data_root.glob("diag*")) | set(extra_diagnostics))
    for base in series_bases:
        if not (base / "results.csv").exists():
            continue
        raw = read_csv(base / "results.csv")
        audited = []
        for row in raw:
            path = base / "logs" / ("r" + row["round"] + "_" + row["api"] + "_" + row["mode"] + ".log")
            content = path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""
            match = pattern.search(content)
            realtime = float(match.group(1)) if match else None
            monotonic = float(match.group(2)) if match else None
            difference = monotonic - realtime if match else None
            cpu = float(row["user_s"]) + float(row["sys_s"])
            audited.append({"round": row["round"], "position": row["position"], "api": row["api"],
                            "mode": row["mode"], "iterations": int(row["iterations"]),
                            "csv_wall_s": float(row["wall_s"]), "log_realtime_s": realtime,
                            "log_monotonic_s": monotonic, "cpu_user_plus_sys_s": cpu,
                            "monotonic_minus_realtime_s": difference,
                            "abs_difference_s": abs(difference) if match else None,
                            "difference_over_1ms": int(abs(difference) > 0.001) if match else None,
                            "difference_over_100ms": int(abs(difference) > 0.1) if match else None,
                            "cpu_exceeds_realtime_plus_30ms": int(cpu > realtime + 0.03) if match else None,
                            "successful_traversals": content.count("OK (436905 nodes processed)"),
                            "expected_traversals": int(row["iterations"]),
                            "log_csv_match": int(abs(monotonic - float(row["wall_s"])) < 1e-7) if match else None})
        write_csv(output / (base.name + "-clock.csv"), audited)
        sampled = [row for row in audited if row["abs_difference_s"] is not None]
        groups = {}
        for api in APIS:
            for mode in MODES:
                group = [row for row in audited if row["api"] == api and row["mode"] == mode]
                if not group:
                    continue
                groups[api + "/" + mode] = {
                    "n": len(group), "sum_wall_s": sum(row["csv_wall_s"] for row in group),
                    "clock_over_1ms": sum(row["difference_over_1ms"] or 0 for row in group),
                    "max_abs_difference_s": max(row["abs_difference_s"] or 0 for row in group),
                    "mean_realtime_ms_per_pass": statistics.mean(
                        row["log_realtime_s"] * 1000 / row["iterations"] for row in group)
                    if all(row["log_realtime_s"] is not None for row in group) else None,
                }
        before, after = snapshot_date(base / "meta_before.txt"), snapshot_date(base / "meta_after.txt")
        timestamps = [int(row["timestamp"]) for row in raw]
        summary[base.name] = {
            "data_rows": len(raw), "groups": groups,
            "failed_exit_rows": sum(int(row["exit_code"]) != 0 for row in raw),
            "bad_cpu_check_rows": sum(row["cpu_check"] != "ok" for row in raw),
            "bad_node_rows": sum(int(row["nodes"]) != 436905 for row in raw),
            "incorrect_log_traversal_rows": sum(row["successful_traversals"] != row["expected_traversals"] for row in audited),
            "clock_logged_rows": len(sampled),
            "clock_over_1ms": sum(row["difference_over_1ms"] for row in sampled),
            "clock_over_100ms": sum(row["difference_over_100ms"] for row in sampled),
            "max_abs_difference_s": max((row["abs_difference_s"] for row in sampled), default=None),
            "sum_wall_s": sum(float(row["wall_s"]) for row in raw),
            "sum_realtime_s": sum(row["log_realtime_s"] for row in sampled),
            "snapshot_duration_s": (after - before).total_seconds() if before and after else None,
            "timestamp_regressions": sum(second < first for first, second in zip(timestamps, timestamps[1:])),
            "worst_rows": sorted(sampled, key=lambda row: row["abs_difference_s"], reverse=True)[:8],
        }
    for base in diagnostic_bases:
        if not (base / "measurements.csv").exists():
            if (base / "tool_overhead.csv").exists():
                tools = read_csv(base / "tool_overhead.csv")
                loads = read_csv(base / "load.csv") if (base / "load.csv").exists() else []
                summary[base.name] = {"schema": "legacy", "measured_rows": len(tools) + len(loads),
                                      "clock_logged_rows": 0, "clock_over_1ms": None,
                                      "clock_over_100ms": None, "max_abs_difference_s": None,
                                      "sum_wall_s": sum(float(row["wall_s"]) for row in tools + loads),
                                      "sum_realtime_s": None, "worst_rows": [],
                                      "clock_status": "unavailable_no_individual_double_clock_records"}
            continue
        rows = read_csv(base / "measurements.csv")
        audited = []
        for row in rows:
            wall, realtime = float(row["wall_s"]), float(row["realtime_s"])
            audited.append({**row, "abs_difference_s": abs(wall - realtime),
                            "monotonic_minus_realtime_s": wall - realtime,
                            "difference_over_1ms": int(abs(wall - realtime) > 0.001)})
        write_csv(output / (base.name + "-clock.csv"), audited)
        summary[base.name] = {
            "measured_rows": len(rows), "invalid_rows": sum(int(row["valid"]) != 1 for row in rows),
            "clock_over_1ms": sum(row["difference_over_1ms"] for row in audited),
            "clock_over_100ms": sum(row["abs_difference_s"] > 0.1 for row in audited),
            "max_abs_difference_s": max(row["abs_difference_s"] for row in audited),
            "sum_wall_s": sum(float(row["wall_s"]) for row in rows),
            "sum_realtime_s": sum(float(row["realtime_s"]) for row in rows),
            "worst_rows": sorted(audited, key=lambda row: row["abs_difference_s"], reverse=True)[:5],
        }
    (output / "timing-audit.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary


def summarize_main(rows):
    groups = defaultdict(list)
    seen = set()
    for row in rows:
        key = row["api"], row["mode"]
        if key[0] not in APIS or key[1] not in MODES:
            raise ValueError("Unexpected main-series configuration")
        if row["exit_code"] != "0" or row["nodes"] != "436905":
            raise ValueError("A main-series run failed validation")
        if row["cache"] != "warm" or row["graph"] != "graph-seq.bin":
            raise ValueError("Unexpected graph or cache methodology")
        iterations, round_id = int(row["iterations"]), int(row["round"])
        wall = float(row["wall_s"])
        if iterations <= 0 or wall <= 0 or (key, round_id) in seen:
            raise ValueError("Invalid or duplicate main-series observation")
        seen.add((key, round_id))
        row["round_id"] = round_id
        row["ms_per_pass"] = 1000 * wall / iterations
        groups[key].append(row)
    if set(groups) != {(api, mode) for api in APIS for mode in MODES}:
        raise ValueError("All four main-series groups are required")
    if len({len(group) for group in groups.values()}) != 1:
        raise ValueError("Main-series counts differ between groups")
    summary = []
    for api in APIS:
        for mode in MODES:
            group = groups[api, mode]
            stats = describe([row["ms_per_pass"] for row in group])
            approx_n, refined_n = estimated_n(stats["sample_sd"], 0.05 * stats["mean"])
            result = {"api": api, "mode": mode, "unit": "ms_per_pass", **stats,
                      "n_5pct_normal_approx": approx_n, "n_5pct_t_refined": refined_n,
                      "reaches_5pct_target_retrospectively": stats["relative_halfwidth_pct"] <= 5,
                      "cpu_check_bad_count": sum(row["cpu_check"] == "bad" for row in group),
                      "iterations": int(group[0]["iterations"]),
                      "clock_status": "pending_separate_timing_audit"}
            summary.append(result)
    paired = []
    resource = []
    for api in APIS:
        read_by_round = {row["round_id"]: row for row in groups[api, "read"]}
        write_by_round = {row["round_id"]: row for row in groups[api, "write"]}
        if read_by_round.keys() != write_by_round.keys():
            raise ValueError("Read and write rounds do not match")
        differences = [write_by_round[round_id]["ms_per_pass"] - read_by_round[round_id]["ms_per_pass"]
                       for round_id in sorted(read_by_round)]
        read_mean = statistics.mean(row["ms_per_pass"] for row in read_by_round.values())
        write_mean = statistics.mean(row["ms_per_pass"] for row in write_by_round.values())
        paired.append({"api": api, "comparison": "write_minus_read", "unit": "ms_per_pass",
                       **describe(differences), "ratio_of_means_write_over_read": write_mean / read_mean,
                       "percent_increase_of_means": 100 * (write_mean / read_mean - 1),
                       "clock_status": "pending_separate_timing_audit"})
        for mode in MODES:
            group = groups[api, mode]
            result = {"api": api, "mode": mode, "n": len(group),
                      "iterations": int(group[0]["iterations"])}
            for field in RESOURCE_FIELDS:
                result["mean_" + field + "_per_run"] = statistics.mean(float(row[field]) for row in group)
                result["mean_" + field + "_per_pass"] = statistics.mean(
                    float(row[field]) / int(row["iterations"]) for row in group)
            result["cpu_time_exceeds_wall_count"] = sum(
                float(row["user_s"]) + float(row["sys_s"]) > float(row["wall_s"])
                for row in group)
            resource.append(result)
    return groups, summary, paired, resource


def summarize_diagnostics(rows, loads):
    groups = defaultdict(list)
    for row in rows:
        if row.get("schema") == "legacy" or (row.get("valid") == "1" and row.get("exit_code") == "0"):
            groups[row["phase"], row["api"], row["mode"], row["tool"]].append(row)
    summaries = []
    for key, group in sorted(groups.items()):
        result = {"phase": key[0], "api": key[1], "mode": key[2], "tool": key[3],
                  "unit": "ms_per_pass", **describe([1000 * float(row["wall_s"]) / int(row["iterations"])
                                                       for row in group]),
                  "iterations": int(group[0]["iterations"]),
                  "clock_status": "pending_separate_timing_audit"}
        summaries.append(result)
    overhead = []
    for api in APIS:
        for mode in MODES:
            baseline = groups.get(("tools", api, mode, "bare"), [])
            bare = {int(row["rep"]): row for row in baseline}
            if not bare:
                continue
            for tool in ("time_v", "strace", "perf"):
                instrumented = groups.get(("tools", api, mode, tool), [])
                measured = {int(row["rep"]): row for row in instrumented}
                if not measured:
                    continue
                if bare.keys() != measured.keys():
                    raise ValueError("Diagnostic tool rounds do not match")
                difference = [1000 * (float(measured[rep]["wall_s"]) - float(bare[rep]["wall_s"]))
                              / int(bare[rep]["iterations"]) for rep in sorted(bare)]
                bare_mean = statistics.mean(float(row["wall_s"]) for row in baseline)
                tool_mean = statistics.mean(float(row["wall_s"]) for row in instrumented)
                overhead.append({"api": api, "mode": mode, "tool": tool,
                                 "comparison": "tool_minus_bare", "unit": "ms_per_pass",
                                 **describe(difference), "ratio_of_means": tool_mean / bare_mean,
                                 "percent_increase_of_means": 100 * (tool_mean / bare_mean - 1),
                                 "clock_status": "pending_separate_timing_audit"})
    load_groups = defaultdict(list)
    for row in loads:
        load_groups[row["api"], row["condition"]].append(row)
    load_summaries = []
    load_pairs = []
    for api in APIS:
        for condition in ("quiet", "stress"):
            group = load_groups.get((api, condition), [])
            if not group:
                continue
            result = {"api": api, "condition": condition, "unit": "s_per_run",
                      **describe([float(row["wall_s"]) for row in group]),
                      "iterations": int(group[0]["iterations"]),
                      "clock_status": "pending_separate_timing_audit"}
            for field in RESOURCE_FIELDS:
                result["mean_" + field + "_per_run"] = statistics.mean(float(row[field]) for row in group)
            load_summaries.append(result)
        quiet = {int(row["rep"]): row for row in load_groups.get((api, "quiet"), [])}
        stress = {int(row["rep"]): row for row in load_groups.get((api, "stress"), [])}
        if not quiet and not stress:
            continue
        if quiet.keys() != stress.keys():
            raise ValueError("Quiet and stress rounds do not match")
        differences = [float(stress[rep]["wall_s"]) - float(quiet[rep]["wall_s"])
                       for rep in sorted(quiet)]
        quiet_mean = statistics.mean(float(row["wall_s"]) for row in quiet.values())
        stress_mean = statistics.mean(float(row["wall_s"]) for row in stress.values())
        load_pairs.append({"api": api, "comparison": "stress_minus_quiet", "unit": "s_per_run",
                           **describe(differences), "ratio_of_means": stress_mean / quiet_mean,
                           "percent_increase_of_means": 100 * (stress_mean / quiet_mean - 1),
                           "clock_status": "pending_separate_timing_audit"})
    return summaries, overhead, load_summaries, load_pairs


def historical_comparison(args, current_summary, current_diagnostics):
    historical_path = args.root / "data" / "series-20260928-212158-reconstructed" / "results.csv"
    tool_path = args.root / "data" / "historical-transcript" / "tool_overhead.csv"
    historical = []
    comparison = []
    tool_comparison = []
    if historical_path.exists():
        _, historical, _, _ = summarize_main(read_csv(historical_path))
        for old in historical:
            old["clock_status"] = "printed_transcript_reconstruction;individual_clock_logs_unavailable"
            new = next(row for row in current_summary if row["api"] == old["api"] and row["mode"] == old["mode"])
            comparison.append({"api": old["api"], "mode": old["mode"], "unit": "ms_per_pass",
                               "historical_provenance": "120_printed_rows_reconstructed_from_terminal_transcript",
                               "historical_n": old["n"], "historical_mean": old["mean"],
                               "historical_sample_sd": old["sample_sd"],
                               "historical_ci95_low": old["ci95_low"], "historical_ci95_high": old["ci95_high"],
                               "current_n": new["n"], "current_mean": new["mean"],
                               "current_sample_sd": new["sample_sd"], "current_ci95_low": new["ci95_low"],
                               "current_ci95_high": new["ci95_high"],
                               "current_vs_historical_percent_change": 100 * (new["mean"] / old["mean"] - 1),
                               "causal_interpretation": "different_dates_and_protocol_context;not_a_controlled_version_effect"})
        write_csv(args.output / "historical-reconstructed-main-summary.csv", historical)
        write_csv(args.output / "historical-vs-current-main.csv", comparison)
    if tool_path.exists():
        tool_groups = defaultdict(list)
        for row in read_csv(tool_path):
            tool_groups[row["api"], row["tool"]].append(float(row["wall_s"]))
        for (api, tool), values in sorted(tool_groups.items()):
            old = describe(values)
            new = next(row for row in current_diagnostics
                       if row["phase"] == "tools" and row["api"] == api
                       and row["mode"] == "read" and row["tool"] == tool)
            # Both preserved protocols use one traversal for tool-overhead comparisons.
            current_mean_s = new["mean"] / 1000
            tool_comparison.append({"api": api, "mode": "read", "tool": tool, "iterations": 1,
                                    "historical_provenance": "printed_B_tool_overhead_rows",
                                    "historical_n": old["n"], "historical_mean_s": old["mean"],
                                    "historical_ci95_low_s": old["ci95_low"],
                                    "historical_ci95_high_s": old["ci95_high"],
                                    "current_n": new["n"], "current_mean_s": current_mean_s,
                                    "current_ci95_low_s": new["ci95_low"] / 1000,
                                    "current_ci95_high_s": new["ci95_high"] / 1000,
                                    "historical_over_current_ratio": old["mean"] / current_mean_s,
                                    "historical_mean_times_10_s": old["mean"] * 10,
                                    "clock_status": "historical_dual_clock_logs_absent;current_clock_disagreements_logged"})
        write_csv(args.output / "historical-vs-current-tools.csv", tool_comparison)
    return historical, comparison, tool_comparison


def svg_start(width, height):
    return [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
            '<rect width="100%" height="100%" fill="white"/>',
            '<style>text{font-family:DejaVu Sans,Arial,sans-serif;fill:#243746} .grid{stroke:#E1E7ED;stroke-width:1} .axis{stroke:#657687;stroke-width:1.2}</style>']


def text_svg(x, y, value, size=14, anchor="start", fill=None):
    color = f' style="fill:{fill}"' if fill else ""
    return f'<text x="{x:.2f}" y="{y:.2f}" font-size="{size}" text-anchor="{anchor}"{color}>{html.escape(str(value))}</text>'


def line_svg(x1, y1, x2, y2, color, width=1.0):
    return f'<line x1="{x1:.3f}" y1="{y1:.3f}" x2="{x2:.3f}" y2="{y2:.3f}" stroke="{color}" stroke-width="{width}"/>'


def nice_top(value):
    exponent = 10 ** math.floor(math.log10(value)) if value else 1
    return math.ceil(value / exponent / 0.5) * 0.5 * exponent


def panel_axes(parts, x, y, width, height, xmin, xmax, ymax, labels, xlabel=None):
    for step in range(6):
        position = y + height - height * step / 5
        parts.append(line_svg(x, position, x + width, position, "#E1E7ED"))
        parts.append(text_svg(x - 10, position + 5, f"{ymax * step / 5:.3g}", 12, "end"))
    parts.append(line_svg(x, y, x, y + height, "#657687", 1.2))
    parts.append(line_svg(x, y + height, x + width, y + height, "#657687", 1.2))
    parts.append(text_svg(x, y - 17, labels["density_y"] if xlabel == "density" else labels["time_y"], 12))
    if xlabel:
        for step in range(6):
            value = xmin + (xmax - xmin) * step / 5
            if xlabel == "round":
                value = round(value)
            px = x + width * (value - xmin) / (xmax - xmin)
            parts.append(text_svg(px, y + height + 24, f"{value:.3g}", 12, "middle"))
        parts.append(text_svg(x + width / 2, y + height + 55,
                              labels["time_x"] if xlabel == "density" else labels["round_x"], 14, "middle"))


def save_svg(path, parts):
    path.write_text("\n".join(parts + ["</svg>"]), encoding="utf-8")


def plot_main(summary, labels, output):
    parts = svg_start(1200, 580)
    parts.append(text_svg(600, 34, labels["mean_title"], 22, "middle"))
    parts.append(text_svg(600, 61, labels["provisional_short"], 13, "middle"))
    for index, api in enumerate(APIS):
        x, y, width, height = 88 + index * 594, 133, 443, 322
        stats = [item for item in summary if item["api"] == api]
        top = nice_top(max(item["ci95_high"] for item in stats) * 1.16)
        panel_axes(parts, x, y, width, height, 0, 1, top, labels)
        parts.append(text_svg(x + width / 2, 100, labels["api_" + api], 18, "middle"))
        for position, item in enumerate(stats):
            mode = item["mode"]
            px = x + width * (0.28 if position == 0 else 0.72)
            py = lambda value: y + height - height * value / top
            low, high, middle = py(item["ci95_low"]), py(item["ci95_high"]), py(item["mean"])
            parts.append(line_svg(px, low, px, high, COLORS[mode], 3))
            parts.append(line_svg(px - 11, low, px + 11, low, COLORS[mode], 3))
            parts.append(line_svg(px - 11, high, px + 11, high, COLORS[mode], 3))
            parts.append(f'<circle cx="{px:.3f}" cy="{middle:.3f}" r="6" fill="{COLORS[mode]}"/>')
            parts.append(text_svg(px, high - 17, f'{item["mean"]:.3f} +/- {item["ci95_halfwidth"]:.3f}', 13, "middle"))
            parts.append(text_svg(px, y + height + 28, labels[mode], 15, "middle"))
    parts.append(text_svg(600, 537, labels["mean_caption"], 13, "middle"))
    save_svg(output / "means-ci-ru.svg", parts)


def histogram(values, edges):
    counts = [0] * (len(edges) - 1)
    width = edges[1] - edges[0]
    for value in values:
        index = min(len(counts) - 1, max(0, int((value - edges[0]) / width)))
        counts[index] += 1
    return [count / len(values) / width for count in counts]


def plot_histograms(groups, labels, output):
    parts = svg_start(1200, 615)
    parts.append(text_svg(600, 34, labels["density_title"], 22, "middle"))
    parts.append(text_svg(600, 61, labels["provisional_short"], 13, "middle"))
    diagnostics = []
    for index, api in enumerate(APIS):
        values = {mode: [row["ms_per_pass"] for row in groups[api, mode]] for mode in MODES}
        combined = values["read"] + values["write"]
        span = max(combined) - min(combined)
        low, high = min(combined) - 0.06 * span, max(combined) + 0.06 * span
        within_span = max(max(sample) - min(sample) for sample in values.values())
        bins = min(120, max(20, math.ceil((high - low) / max(within_span / 8, span / 120))))
        edges = [low + (high - low) * step / bins for step in range(bins + 1)]
        density = {mode: histogram(values[mode], edges) for mode in MODES}
        top = nice_top(max(max(items) for items in density.values()) * 1.08)
        x, y, width, height = 88 + index * 594, 154, 443, 321
        panel_axes(parts, x, y, width, height, low, high, top, labels, "density")
        parts.append(text_svg(x + width / 2, 98, labels["api_" + api], 18, "middle"))
        for mode, offset in (("read", 0), ("write", 1)):
            legend_x = x + 93 + 145 * offset
            parts.append(f'<rect x="{legend_x}" y="116" width="19" height="12" fill="{COLORS[mode]}" fill-opacity="0.5"/>')
            parts.append(text_svg(legend_x + 27, 128, labels[mode], 13))
            for bin_id, level in enumerate(density[mode]):
                px = x + width * bin_id / bins
                bar_height = height * level / top
                parts.append(f'<rect x="{px:.3f}" y="{y + height - bar_height:.3f}" width="{width / bins:.3f}" height="{bar_height:.3f}" fill="{COLORS[mode]}" fill-opacity="0.43" stroke="{COLORS[mode]}" stroke-width="0.55"/>')
            area = sum(level * (edges[1] - edges[0]) for level in density[mode])
            diagnostics.append({"api": api, "mode": mode, "bins": bins,
                                "bin_width_ms": edges[1] - edges[0], "density_area": area})
    parts.append(text_svg(600, 576, labels["density_caption"], 13, "middle"))
    save_svg(output / "read-write-density-ru.svg", parts)
    return diagnostics


def plot_rounds(groups, labels, output):
    parts = svg_start(1200, 580)
    parts.append(text_svg(600, 34, labels["round_title"], 22, "middle"))
    parts.append(text_svg(600, 61, labels["provisional_short"], 13, "middle"))
    for index, api in enumerate(APIS):
        x, y, width, height = 88 + index * 594, 151, 443, 311
        top = nice_top(max(row["ms_per_pass"] for mode in MODES for row in groups[api, mode]) * 1.05)
        first = min(row["round_id"] for row in groups[api, "read"])
        last = max(row["round_id"] for row in groups[api, "read"])
        panel_axes(parts, x, y, width, height, first, last, top, labels, "round")
        parts.append(text_svg(x + width / 2, 98, labels["api_" + api], 18, "middle"))
        for mode, offset in (("read", 0), ("write", 1)):
            legend_x = x + 93 + 145 * offset
            parts.append(line_svg(legend_x, 122, legend_x + 21, 122, COLORS[mode], 2))
            parts.append(text_svg(legend_x + 27, 128, labels[mode], 13))
            coordinates = []
            for row in sorted(groups[api, mode], key=lambda row: row["round_id"]):
                px = x + width * (row["round_id"] - first) / (last - first)
                py = y + height - height * row["ms_per_pass"] / top
                coordinates.append(f"{px:.3f},{py:.3f}")
                parts.append(f'<circle cx="{px:.3f}" cy="{py:.3f}" r="2.5" fill="{COLORS[mode]}"/>')
            points = " ".join(coordinates)
            parts.append(f'<polyline points="{points}" fill="none" stroke="{COLORS[mode]}" stroke-width="1.6"/>')
    save_svg(output / "run-order-ru.svg", parts)


def write_report(labels, summary, paired, resources, tools, loads, load_pairs, clock_audit, history, args, output):
    lines = [labels["report_title"], "", labels["timing_note"], "", labels["clock_heading"], ""]
    for name in (args.series_name, args.diagnostics_name):
        info = clock_audit[name]
        if info["max_abs_difference_s"] is not None:
            lines.append(labels["clock_line"].format(name=name, n=info.get("data_rows", info.get("measured_rows")),
                                                     count=info["clock_over_100ms"], maximum=info["max_abs_difference_s"]))
    main_info = clock_audit[args.series_name]
    lines += [""]
    if args.series_name == "series-20261011-163118-1889":
        lines += [labels["clock_interpretation"], ""]
    if main_info["snapshot_duration_s"] is not None and main_info["clock_logged_rows"]:
        lines += [labels["clock_total"].format(monotonic=main_info["sum_wall_s"], realtime=main_info["sum_realtime_s"],
                                             duration=main_info["snapshot_duration_s"]), ""]
    lines += [
             labels["method_heading"], "", labels["method_text"], "",
             labels["summary_heading"], "", labels["summary_header"],
             "|---|---|---:|---:|---:|---:|---:|---:|"]
    for row in summary:
        lines.append(f'| {row["api"]} | {labels[row["mode"]]} | {row["n"]} | {row["mean"]:.6f} | {row["sample_sd"]:.6f} | {row["ci95_low"]:.6f} - {row["ci95_high"]:.6f} | {row["relative_halfwidth_pct"]:.3f}% | {row["iqr_flagged_retained"]} |')
    lines += ["", labels["n_heading"], "", labels["n_text"], ""]
    for row in summary:
        lines.append(labels["n_line"].format(api=row["api"], mode=labels[row["mode"]],
                                            halfwidth=row["relative_halfwidth_pct"],
                                            approximate=row["n_5pct_normal_approx"], refined=row["n_5pct_t_refined"]))
    lines += ["", labels["paired_heading"], ""]
    for row in paired:
        lines.append(labels["paired_line"].format(api=row["api"], n=row["n"], mean=row["mean"],
                                                 low=row["ci95_low"], high=row["ci95_high"],
                                                 ratio=row["ratio_of_means_write_over_read"],
                                                 percent=row["percent_increase_of_means"]))
    lines += ["", labels["paired_caution"], "", labels["main_interpretation"], "", labels["resources_heading"], "", labels["resources_header"],
              "|---|---|---:|---:|---:|---:|---:|---:|"]
    for row in resources:
        lines.append(f'| {row["api"]} | {labels[row["mode"]]} | {row["mean_user_s_per_run"]:.6f} | {row["mean_sys_s_per_run"]:.6f} | {row["mean_vol_ctx_per_run"]:.3f} | {row["mean_invol_ctx_per_run"]:.3f} | {row["mean_minflt_per_run"]:.3f} | {row["mean_majflt_per_run"]:.3f} |')
    lines += ["", labels["resource_caution"], ""]
    if args.series_name == "series-20261011-163118-1889":
        lines += [labels["resource_interpretation"], ""]
    lines += [labels["tools_heading"], ""]
    if args.diagnostic_notes["schema"] == "modern" and args.diagnostics_name == "diag-20261011-162607-1218":
        lines += [labels["tools_text"], ""]
    lines += [
              labels["tools_header"], "|---|---|---|---:|---:|---:|"]
    for row in tools:
        lines.append(f'| {row["api"]} | {labels[row["mode"]]} | {row["tool"]} | {row["n"]} | {row["ratio_of_means"]:.3f} | {row["ci95_low"]:.3f} - {row["ci95_high"]:.3f} |')
    lines += [""]
    if args.diagnostic_notes["schema"] == "modern" and args.diagnostics_name == "diag-20261011-162607-1218":
        lines += [labels["tool_interpretation"], "", labels["perf_note"], ""]
    lines += [labels["load_heading"], ""]
    if args.diagnostic_notes["schema"] == "modern" and args.diagnostics_name == "diag-20261011-162607-1218":
        lines += [labels["load_text"], ""]
    lines += [
              labels["load_header"], "|---|---|---:|---:|---:|---:|"]
    for row in loads:
        lines.append(f'| {row["api"]} | {labels["condition_" + row["condition"]]} | {row["n"]} | {row["mean"]:.6f} | {row["ci95_low"]:.6f} - {row["ci95_high"]:.6f} | {row["mean_invol_ctx_per_run"]:.3f} |')
    lines += [""]
    for row in load_pairs:
        lines.append(labels["load_pair_line"].format(api=row["api"], mean=row["mean"], low=row["ci95_low"],
                                                    high=row["ci95_high"], ratio=row["ratio_of_means"]))
    lines += [""]
    if args.diagnostic_notes["schema"] == "modern" and args.diagnostics_name == "diag-20261011-162607-1218":
        lines += [labels["small_n_note"], ""]
    historical, historical_main, historical_tools = history
    if historical_main:
        lines += [labels["history_heading"], "", labels["history_note"], "", labels["history_header"],
                  "|---|---|---:|---:|---:|---:|"]
        for row in historical_main:
            lines.append(f'| {row["api"]} | {labels[row["mode"]]} | {row["historical_n"]} | {row["historical_mean"]:.6f} | {row["current_mean"]:.6f} | {row["current_vs_historical_percent_change"]:.2f}% |')
        lines += ["", labels["history_caution"], ""]
    if historical_tools:
        lines += [labels["history_tools_heading"], "", labels["history_tools_note"], "", labels["history_tools_header"],
                  "|---|---|---:|---:|---:|---:|"]
        for row in historical_tools:
            lines.append(f'| {row["api"]} | {row["tool"]} | {row["historical_n"]} | {row["historical_mean_s"]:.6f} | {row["current_n"]} | {row["current_mean_s"]:.6f} |')
        read_strace = next(row for row in historical_tools if row["api"] == "read_lseek" and row["tool"] == "strace")
        lines += ["", labels["history_tools_estimate"].format(mean=read_strace["historical_mean_s"],
                                                              estimate=read_strace["historical_mean_times_10_s"],
                                                              minutes=read_strace["historical_mean_times_10_s"] / 60,
                                                              ratio=read_strace["historical_over_current_ratio"]), ""]
    lines += [labels["interpretation_heading"], "", labels["cache_write_note"], "",
              labels["figures_heading"], "", labels["figures_text"], "", labels["density_method"], "",
              labels["source_heading"], "", labels["sources"], ""]
    (output / "analysis-ru.md").write_text("\n".join(lines), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--series", default="series-20261011-163118-1889")
    parser.add_argument("--diagnostics", default="diag-20261011-162607-1218")
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--load-api", choices=APIS, help="Required when legacy load.csv has no api column")
    parser.add_argument("--trace-iterations", type=int, default=1, help="Historical B TRACE_ITER; record the actual value")
    parser.add_argument("--load-iterations", type=int, default=20, help="Historical C ITER; record the actual value")
    args = parser.parse_args()
    if args.trace_iterations <= 0 or args.load_iterations <= 0:
        parser.error("Historical iteration counts must be positive")
    args.root = args.root.expanduser().resolve()
    args.output = args.output.expanduser().resolve()
    labels_path = args.root / "docs" / "figure-labels-ru.json"
    labels = json.loads(labels_path.read_text(encoding="utf-8-sig"))
    series_dir = resolve_run_directory(args.root, args.series)
    series_file = series_dir / "results.csv"
    diagnostics_dir = resolve_run_directory(args.root, args.diagnostics)
    args.series_name, args.diagnostics_name = series_dir.name, diagnostics_dir.name
    diagnostic_rows, diagnostic_loads, diagnostic_files, args.diagnostic_notes = read_diagnostic_input(diagnostics_dir, args)
    inputs = [series_file, *diagnostic_files]
    for path in (args.root / "data" / "series-20260928-212158-reconstructed" / "results.csv",
                 args.root / "data" / "historical-transcript" / "tool_overhead.csv"):
        if path.exists():
            inputs.append(path)
    original_hashes = {input_key(args.root, path): hashlib.sha256(path.read_bytes()).hexdigest()
                       for path in inputs}
    groups, summary, paired, resources = summarize_main(read_csv(series_file))
    diagnostics, tools, loads, load_pairs = summarize_diagnostics(diagnostic_rows, diagnostic_loads)
    args.output.mkdir(parents=True, exist_ok=True)
    clock_audit = audit_clocks(args.root / "data", args.output / "clock-audit", [series_dir], [diagnostics_dir])
    main_clock = clock_audit[args.series_name]
    main_status = CLOCK_STATUS if main_clock["clock_over_100ms"] else (
        "no_large_clock_disagreement_logged;independent_accuracy_unverified" if main_clock["clock_logged_rows"]
        else "unavailable_no_individual_clock_records;independent_accuracy_unverified")
    for table in (summary, paired):
        for row in table:
            row["clock_status"] = main_status
    for table in (diagnostics, tools, loads, load_pairs):
        for row in table:
            row["clock_status"] = CLOCK_STATUS if args.diagnostic_notes["schema"] == "modern" else "unavailable_no_individual_clock_records"
    history = historical_comparison(args, summary, diagnostics)
    if args.series_name != "series-20261011-163118-1889":
        labels = dict(labels)
        # Retain generic Russian text from the external labels; omit dataset-specific claims.
        sentences = labels["timing_note"].split(". ")
        labels["timing_note"] = ". ".join(sentence for index, sentence in enumerate(sentences) if index != 2)
        labels["provisional_short"] = labels["provisional_short"].split(":", 1)[0]
        labels["main_interpretation"] = ""
        labels["figures_text"] = ""
        count = summary[0]["n"]
        iterations = summary[0]["iterations"]
        labels["mean_caption"] = labels["mean_caption"].replace("N = 30", f"N = {count}").replace("ITER = 20", f"ITER = {iterations}")
        labels["method_text"] = labels["method_text"].replace("N = 30", f"N = {count}").replace("ITER = 20", f"ITER = {iterations}")
        labels["method_text"] = ". ".join(sentence for sentence in labels["method_text"].split(". ")
                                          if "2,045229642" not in sentence and "600" not in sentence)
    for name, table in (("main-summary.csv", summary), ("paired-read-write.csv", paired),
                        ("main-resources.csv", resources), ("diagnostic-summary.csv", diagnostics),
                        ("tool-overhead.csv", tools), ("background-load-summary.csv", loads),
                        ("paired-background-load.csv", load_pairs)):
        write_csv(args.output / name, table)
    plot_main(summary, labels, args.output)
    histogram_checks = plot_histograms(groups, labels, args.output)
    plot_rounds(groups, labels, args.output)
    write_report(labels, summary, paired, resources, tools, loads, load_pairs, clock_audit, history, args, args.output)
    final_hashes = {input_key(args.root, path): hashlib.sha256(path.read_bytes()).hexdigest()
                    for path in inputs}
    if final_hashes != original_hashes:
        raise RuntimeError("An input file changed during analysis")
    expected = {1: 12.7062047361747, 2: 4.3026527299113, 29: 2.0452296421327}
    quantile_checks = {str(df): {"computed": student_quantile(df), "reference": reference,
                                 "absolute_error": abs(student_quantile(df) - reference)}
                       for df, reference in expected.items()}
    if any(item["absolute_error"] > 1e-9 for item in quantile_checks.values()):
        raise ArithmeticError("Student t quantile verification failed")
    if any(abs(item["density_area"] - 1) > 1e-10 for item in histogram_checks):
        raise ArithmeticError("Histogram density normalization failed")
    checks = {"input_sha256": original_hashes, "input_files_unchanged": True,
              "main_row_count": sum(len(group) for group in groups.values()),
              "main_group_counts": {api + "/" + mode: len(groups[api, mode]) for api in APIS for mode in MODES},
              "historical_reconstructed_row_count": sum(row["n"] for row in history[0]),
              "historical_reconstructed_group_counts": {row["api"] + "/" + row["mode"]: row["n"] for row in history[0]},
              "student_quantile_checks": quantile_checks, "histogram_checks": histogram_checks,
              "perf_available": any(row["tool"] == "perf" for row in diagnostics),
              "timing_consistency": "clock_disagreement_detected; raw_monotonic_statistics_are_conditional" if main_clock["clock_over_100ms"] else main_status,
              "independent_sampling_unit": "one_process_run; iterations_are_not_independent_samples",
              "excluded_valid_outliers": 0}
    if args.diagnostic_notes["schema"] == "legacy":
        checks["legacy_diagnostic_input_notes"] = args.diagnostic_notes
        (args.output / "diagnostic-input-notes.json").write_text(json.dumps(args.diagnostic_notes, indent=2), encoding="utf-8")
    (args.output / "validation.json").write_text(json.dumps(checks, indent=2), encoding="utf-8")
    (args.output / "statistics.json").write_text(json.dumps({"main": summary, "paired": paired,
                                                              "resources": resources, "diagnostics": diagnostics,
                                                              "tools": tools, "loads": loads,
                                                              "load_pairs": load_pairs,
                                                              "historical_reconstructed": history[0],
                                                              "historical_main_comparison": history[1],
                                                              "historical_tool_comparison": history[2]}, indent=2), encoding="utf-8")
    print(f"Analyzed {checks['main_row_count']} main rows in four groups; output: {args.output}")
    print("Input hashes unchanged. Clock disagreements are logged; monotonic conclusions are conditional.")


if __name__ == "__main__":
    main()
