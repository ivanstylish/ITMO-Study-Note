#!/usr/bin/env python3
# analyze_diag.py <diag 目录> -- 汇总 tool_overhead.csv 与 load.csv：均值、s、95% t 置信区间、与基线之比
# 只用标准库；t 分位数取自 t(0.975, df) 表，df>30 时近似取 1.96。
import csv, math, statistics, sys
from collections import defaultdict

T975 = [12.706, 4.303, 3.182, 2.776, 2.571, 2.447, 2.365, 2.306, 2.262, 2.228,
        2.201, 2.179, 2.160, 2.145, 2.131, 2.120, 2.110, 2.101, 2.093, 2.086,
        2.080, 2.074, 2.069, 2.064, 2.060, 2.056, 2.052, 2.048, 2.045, 2.042]

def summary(xs):
    n, m = len(xs), statistics.mean(xs)
    s = statistics.stdev(xs) if n > 1 else float("nan")
    t = T975[n - 2] if 2 <= n <= 31 else 1.96
    half = t * s / math.sqrt(n) if n > 1 else float("nan")
    return n, m, s, half

def group(path, keys, value):
    g = defaultdict(list)
    with open(path) as f:
        for row in csv.DictReader(f):
            g[tuple(row[k] for k in keys)].append(float(row[value]))
    return g

d = sys.argv[1].rstrip("/")
out = []

# ---- B. 工具侵入性：wall（毫秒），与 bare 之比 ----
g = group(f"{d}/tool_overhead.csv", ["api", "tool"], "wall_s")
out.append("B. 工具侵入性（wall，毫秒；ratio = 均值 / 同实现 bare 均值）")
out.append(f"{'api':<11}{'tool':<8}{'N':>3}{'mean':>12}{'s':>10}{'95% CI half':>13}{'ratio':>8}")
for (api, tool), xs in sorted(g.items(), key=lambda kv: (kv[0][0], kv[0][1] != "bare", kv[0][1])):
    n, m, s, h = summary([x * 1000 for x in xs])
    base = statistics.mean(g[(api, "bare")]) * 1000
    out.append(f"{api:<11}{tool:<8}{n:>3}{m:>12.2f}{s:>10.2f}{h:>13.2f}{m / base:>8.2f}")

# ---- C. 背景负载：wall 与被动切换 ----
out.append("")
out.append("C. 背景负载（wall，秒；invol = 被动上下文切换均值）")
w = group(f"{d}/load.csv", ["condition"], "wall_s")
iv = group(f"{d}/load.csv", ["condition"], "invol_ctx")
out.append(f"{'cond':<8}{'N':>3}{'mean':>10}{'s':>9}{'CV%':>7}{'95% CI half':>13}{'invol':>9}{'ratio':>8}")
base = statistics.mean(w[("quiet",)])
for cond in ("quiet", "stress"):
    xs = w[(cond,)]
    n, m, s, h = summary(xs)
    out.append(f"{cond:<8}{n:>3}{m:>10.3f}{s:>9.3f}{100 * s / m:>7.1f}{h:>13.3f}"
               f"{statistics.mean(iv[(cond,)]):>9.1f}{m / base:>8.2f}")

text = "\n".join(out)
print(text)
open(f"{d}/diag_summary.txt", "w").write(text + "\n")
