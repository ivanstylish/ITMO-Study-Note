#!/usr/bin/env bash
# env_snapshot.sh <标签> [输出目录]  -- 环境快照（паспорт системы），写入 <输出目录>/meta_<标签>.txt
# 例：bash env_snapshot.sh before results/series-xxx
# 不用 set -e：WSL 里有些命令/文件可能不存在，缺失就显示 n/a，不能因此中断实验。
set -uo pipefail
cd "$(dirname "$0")"
[[ -f src/graph_traverse.c ]] || cd ../intro-exp      # 定位到 lab/intro-exp

TAG=${1:?用法: bash env_snapshot.sh <标签> [输出目录]}
OUT="${2:-.}/meta_${TAG}.txt"
CORE=${CORE:-n/a}

{
  echo "snapshot=$TAG  date=$(date -Is)"
  echo "params: CORE=$CORE N=${N:-?} ITER=${ITER:-?} WARMUP=${WARMUP:-?}"
  echo "--- os-release ---";   cat /etc/os-release
  echo "--- uname ---";        uname -a
  echo "--- gcc ---";          gcc --version | head -1
  echo "--- lscpu ---";        lscpu
  echo "--- lscpu -e ---";     lscpu -e
  echo "--- nproc ---";        nproc
  echo "--- free -h ---";      free -h
  echo "--- page size ---";    getconf PAGESIZE
  echo "--- lsblk ---";        lsblk -o NAME,TYPE,SIZE,ROTA,MODEL,MOUNTPOINTS 2>/dev/null || echo n/a
  echo "--- 实验文件所在文件系统 ---"; findmnt -T . 2>/dev/null || echo n/a
  echo "--- CPU governor (core $CORE) ---"
  cat /sys/devices/system/cpu/cpu"$CORE"/cpufreq/scaling_governor 2>/dev/null || echo "n/a (WSL2 通常没有 cpufreq)"
  echo "--- uptime ---";       uptime
  echo "--- top ---";          top -bn1 | head -15
  echo "--- sha256：程序、数据、脚本 ---"
  sha256sum src/graph_traverse.c src/graph_traverse_mmap.c src/graph_io.h ../util/graphgen.py \
            graph-seq.orig.bin out/graph_traverse out/graph_traverse_mmap 2>/dev/null || echo n/a
} > "$OUT" 2>&1

echo "环境快照已写入 $OUT"
