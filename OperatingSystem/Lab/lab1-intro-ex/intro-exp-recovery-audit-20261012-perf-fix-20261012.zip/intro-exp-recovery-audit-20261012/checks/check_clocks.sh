#!/usr/bin/env bash
# Inspect clocks without running course programs or background load.
set -euo pipefail
N=${N:-10}
INTERVAL=${INTERVAL:-1}
OUTPUT=${1:-clock-check.csv}
python3 - "$N" "$INTERVAL" "$OUTPUT" <<'PY'
import csv, json, math, sys, time
from pathlib import Path
n, interval, output = int(sys.argv[1]), float(sys.argv[2]), Path(sys.argv[3])
if n < 2 or not math.isfinite(interval) or not 0 < interval <= 5:
    raise SystemExit('ERROR: N must be at least 2 and INTERVAL must be in (0, 5].')
output.parent.mkdir(parents=True, exist_ok=True)
raw_id = getattr(time, 'CLOCK_MONOTONIC_RAW', None)
rows = []
for index in range(1, n + 1):
    real0, mono0 = time.time_ns(), time.monotonic_ns()
    raw0 = time.clock_gettime_ns(raw_id) if raw_id is not None else None
    time.sleep(interval)
    raw1 = time.clock_gettime_ns(raw_id) if raw_id is not None else None
    mono1, real1 = time.monotonic_ns(), time.time_ns()
    real, mono = (real1-real0)/1e9, (mono1-mono0)/1e9
    raw = (raw1-raw0)/1e9 if raw0 is not None else None
    rows.append({'sample': index, 'requested_sleep_s': interval, 'realtime_s': real,
                 'monotonic_s': mono, 'monotonic_raw_s': raw,
                 'realtime_minus_monotonic_s': real-mono,
                 'raw_minus_monotonic_s': raw-mono if raw is not None else None})
with output.open('w', newline='', encoding='utf-8') as handle:
    writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
    writer.writeheader(); writer.writerows(rows)
print('Clock observations written to ' + str(output.resolve()))
print('Largest realtime/monotonic difference: %.9f s' % max(abs(r['realtime_minus_monotonic_s']) for r in rows))
print('This short observation does not certify a later experiment run.')
for name in ('time', 'monotonic'):
    print(name + ': ' + str(time.get_clock_info(name)))
PY
