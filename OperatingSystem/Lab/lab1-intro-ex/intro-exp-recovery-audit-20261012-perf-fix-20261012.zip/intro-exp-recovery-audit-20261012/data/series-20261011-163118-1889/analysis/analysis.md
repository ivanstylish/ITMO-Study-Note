# Formal-series analysis

Source file: /home/ivanstylish/course-code/lab/intro-exp/results/series-20261011-163118-1889/results.csv
Each configuration has 30 successful observations in the same rounds.
Metric: wall time divided by the number of traversals, in milliseconds per traversal.
The 95% confidence interval is mean +/- t(0.975, N-1) * s / sqrt(N); s uses denominator N-1.
For N above 30, the t critical value uses a Cornish-Fisher approximation.
No successful observation is dropped as an outlier. Failed runs and incorrect node counts stop analysis.
cpu_check=bad rows remain in the data and are counted; inspect their logs and discuss them.
The paired write-read comparison matches observations from the same round; positive means write took longer.
N sufficiency is checked against a target 5% relative confidence-interval half-width using the observed SD.
For the same SD, doubling N reduces the half-width by about 1/sqrt(2).

| API | Mode | N | Mean ms/pass | SD | 95% CI | Relative half-width | Median | IQR | cpu_check bad | Estimated N for 5% |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| read_lseek | read | 30 | 93.3124 | 1.1009 | [92.9014, 93.7235] | 0.44% | 93.2041 | 1.6676 | 0 | 3 |
| read_lseek | write | 30 | 229.7269 | 2.6431 | [228.7400, 230.7139] | 0.43% | 228.6939 | 3.8180 | 0 | 3 |
| mmap | read | 30 | 1.4886 | 0.1820 | [1.4206, 1.5566] | 4.57% | 1.4192 | 0.1296 | 0 | 26 |
| mmap | write | 30 | 3.1424 | 0.1486 | [3.0869, 3.1979] | 1.77% | 3.0816 | 0.2461 | 0 | 6 |

## Paired write-read comparison

| API | Paired N | Mean write-read ms/pass | 95% CI for difference | Change relative to read |
|---|---:|---:|---:|---:|
| read_lseek | 30 | 136.4145 | [135.5401, 137.2889] | 146.19% |

For read_lseek, the paired interval is above zero: write was slower in this sample.
| mmap | 30 | 1.6538 | [1.5763, 1.7313] | 111.10% |

For mmap, the paired interval is above zero: write was slower in this sample.

See means-ci.svg for the four mean estimates and 95% confidence intervals.
See run-order.svg to inspect drift across interleaved rounds.
An interval overlap is a descriptive check, not a substitute for a paired test; interpret system causes using the logs and diagnostics.
