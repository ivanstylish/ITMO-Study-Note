#!/usr/bin/env bash
# Confirm the plan, then launch the unchanged historical formal script.
set -euo pipefail
SCRIPT_DIR=$(cd -- "$(dirname -- "$0")" && pwd)
cd "$SCRIPT_DIR"
ROOT_DIR=$(cd ../../.. && pwd)
PLAN="$ROOT_DIR/docs/experiment-plan-ru.md"
[[ $(awk '/^STATUS:/ {print; exit}' "$PLAN") == 'STATUS: CONFIRMED' ]] || {
  echo 'ERROR: Review docs/experiment-plan-ru.md and confirm its first STATUS line.' >&2; exit 1;
}
CORE=${CORE:-2}; N=${N:-30}; ITER=${ITER:-20}; WARMUP=${WARMUP:-2}
for name in CORE N ITER WARMUP; do
  [[ ${!name} =~ ^(0|[1-9][0-9]*)$ ]] || { echo "ERROR: Invalid integer: $name" >&2; exit 1; }
  value=$(awk -v key="$name:" '$1==key {print $2; exit}' "$PLAN")
  [[ $value == "${!name}" ]] || { echo "ERROR: $name does not match the confirmed plan." >&2; exit 1; }
done
(( N>=2 && ITER>0 )) || { echo 'ERROR: N must be at least 2 and ITER must be positive.' >&2; exit 1; }
taskset -c "$CORE" true
case "$(findmnt -n -o FSTYPE -T .)" in
  9p|drvfs|ntfs|ntfs3|fuseblk) echo 'ERROR: Run from the Ubuntu home filesystem.' >&2; exit 1 ;;
esac
LAUNCH_DIR="$PWD/results/formal-launch-$(date +%Y%m%d-%H%M%S)-$$"
mkdir -p "$LAUNCH_DIR"
cp "$PLAN" "$SCRIPT_DIR/$(basename "$0")" "$LAUNCH_DIR/"
export CORE N ITER WARMUP
python3 - "$LAUNCH_DIR/whole-series-clocks.json" <<'PY'
import json, subprocess, sys, time
raw_id = getattr(time, 'CLOCK_MONOTONIC_RAW', None)
real0, mono0 = time.time_ns(), time.monotonic_ns()
raw0 = time.clock_gettime_ns(raw_id) if raw_id is not None else None
process = subprocess.run(['bash', 'run_series.sh'])
raw1 = time.clock_gettime_ns(raw_id) if raw_id is not None else None
mono1, real1 = time.monotonic_ns(), time.time_ns()
result = {'exit_code': process.returncode, 'realtime_s': (real1-real0)/1e9,
          'monotonic_s': (mono1-mono0)/1e9,
          'monotonic_raw_s': (raw1-raw0)/1e9 if raw0 is not None else None,
          'scope': 'Whole series including compilation, generation, preparation, warmup and snapshots.'}
with open(sys.argv[1], 'w', encoding='utf-8') as handle:
    json.dump(result, handle, indent=2)
sys.exit(process.returncode)
PY
echo "Whole-series timing audit: $LAUNCH_DIR/whole-series-clocks.json"
