#!/usr/bin/env bash
# Run historical A/B/C workloads twice with their original full defaults.
set -euo pipefail
export LC_ALL=C
SCRIPT_DIR=$(cd -- "$(dirname -- "$0")" && pwd)
cd "$SCRIPT_DIR"
CORE=${CORE:-2}
ITER=${ITER:-20}
TRACE_ITER=${TRACE_ITER:-1}
REPS=${REPS:-10}
PERF=${PERF:-perf}
for name in CORE ITER TRACE_ITER REPS; do
  [[ ${!name} =~ ^(0|[1-9][0-9]*)$ ]] || { echo "ERROR: Invalid integer: $name" >&2; exit 1; }
done
(( ITER>0 && TRACE_ITER>0 && REPS>1 )) || { echo 'ERROR: ITER and TRACE_ITER must be positive; REPS must be at least 2.' >&2; exit 1; }
for cmd in bash python3 taskset timeout strace stress-ng /usr/bin/time; do
  command -v "$cmd" >/dev/null || { echo "ERROR: Missing required tool: $cmd" >&2; exit 1; }
done
taskset -c "$CORE" true
[[ -f graph-seq.orig.bin && -x out/graph_traverse && -x out/graph_traverse_mmap ]] || {
  echo 'ERROR: Run prepare_only.sh first.' >&2; exit 1;
}
RUN_DIR="$PWD/results/full-diagnostics-$(date +%Y%m%d-%H%M%S)-$$"
mkdir -p "$RUN_DIR"
cp "$SCRIPT_DIR/$(basename "$0")" run_diagnostics.sh run_diagnostics_safe.sh env_snapshot.sh mono_time.py analyze_diag.py "$RUN_DIR/"
printf 'CORE=%s ITER=%s TRACE_ITER=%s REPS=%s\n' "$CORE" "$ITER" "$TRACE_ITER" "$REPS" > "$RUN_DIR/parameters.txt"
echo 'Historical A/B/C is repeated for LOAD_API=read_lseek and LOAD_API=mmap; A and B run twice.' >> "$RUN_DIR/parameters.txt"
EVENTS=task-clock,context-switches,cpu-migrations,page-faults,cache-references,cache-misses
SELECTED_PERF="$RUN_DIR/unavailable-perf"
: > "$RUN_DIR/perf-probe.txt"
if command -v "$PERF" >/dev/null && timeout 10 "$PERF" stat -e "$EVENTS" -- true > "$RUN_DIR/perf-probe.txt" 2>&1; then
  if ! grep -Eq 'not supported|not counted|No permission|WARNING: perf not found' "$RUN_DIR/perf-probe.txt"; then
    SELECTED_PERF="$PERF"
  fi
else
  echo 'The historical perf event set is unavailable; see perf-probe.txt.' >> "$RUN_DIR/parameters.txt"
fi
printf 'PERF_SELECTED=%s\n' "$SELECTED_PERF" >> "$RUN_DIR/parameters.txt"
export CORE ITER TRACE_ITER REPS
bash env_snapshot.sh before-full-diagnostics "$RUN_DIR"
for api in read_lseek mmap; do
  echo "Starting historical A/B/C with LOAD_API=$api and REPS=$REPS."
  set +e
  LOAD_API="$api" PERF="$SELECTED_PERF" bash run_diagnostics_safe.sh 2>&1 | tee "$RUN_DIR/$api-console.log"
  code=${PIPESTATUS[0]}
  set -e
  if (( code != 0 )); then
    printf 'FAILED: LOAD_API=%s exit_code=%s; inspect console log.\n' "$api" "$code" > "$RUN_DIR/STATUS.txt"
    exit "$code"
  fi
  diag_dir=$(sed -n 's/^Completed://p' "$RUN_DIR/$api-console.log" | tail -1)
  [[ -n $diag_dir && -f $diag_dir/tool_overhead.csv && -f $diag_dir/load.csv ]] || {
    echo 'ERROR: Historical diagnostic output is incomplete.' >&2; exit 1;
  }
  printf '%s,%s\n' "$api" "$diag_dir" >> "$RUN_DIR/diagnostic-directories.csv"
  python3 analyze_diag.py "$diag_dir"
done
bash env_snapshot.sh after-full-diagnostics "$RUN_DIR"
echo 'COMPLETED: both historical diagnostic implementations.' > "$RUN_DIR/STATUS.txt"
echo "Completed wrapper: $RUN_DIR"
