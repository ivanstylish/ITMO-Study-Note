# 恢复版：简化前的测量与诊断脚本

本目录来自 Ubuntu 中 script-backups/before-simplification-20260928-233854 的历史版本。原始备份没有改动；此副本只把脚本运行时显示的中文提示改成英文，测量逻辑和参数保持原样。Shell/Python 代码中的中文注释保留。

## 文件

- run_series.sh：生成 10 MiB 顺序图并运行四组正式测量。
- run_diagnostics.sh：诊断工具比较、工具开销比较、背景负载对照。
- env_snapshot.sh：记录系统与实验环境。
- mono_time.py：使用单调时钟计时，供两个 Shell 脚本调用。
- analyze_diag.py：汇总诊断数据；诊断运行结束后可单独调用。

这版确实依赖两个 Python 辅助文件，不能只拿 run_diagnostics.sh 单独运行。

## 在 Ubuntu WSL 中使用

当前实验源码仍在 ~/course-code/lab/intro-exp。把这套脚本放在同级目录 ~/course-code/lab/intro-exp-pre-simplification-20260928 中运行，脚本会定位回原实验目录。不要从 Windows 的 /mnt/d 路径直接测量。

如果尚未生成可执行文件和 graph-seq.orig.bin，先运行正式批量测量：

    cd ~/course-code/lab/intro-exp-pre-simplification-20260928
    CORE=2 N=30 ITER=20 WARMUP=2 bash run_series.sh

如果这些正式数据已经完成，无须为诊断重新跑这一阶段。诊断工具要求原实验目录已有 out/graph_traverse、out/graph_traverse_mmap 和 10 MiB 的 graph-seq.orig.bin。

先用两轮做短试跑，然后对两个实现分别做背景负载对照：

    cd ~/course-code/lab/intro-exp-pre-simplification-20260928
    CORE=2 ITER=20 REPS=2 LOAD_API=read_lseek bash run_diagnostics.sh
    CORE=2 ITER=20 REPS=2 LOAD_API=mmap bash run_diagnostics.sh

LOAD_API 每次只指定一种实现。两次运行各自创建新的 results/diag-<时间戳> 目录，不会写入正式测量的 results/series-* 目录。正式诊断可按实验要求把 REPS 提高到 10；这套历史脚本的默认值是 10，完整运行时间会明显长于短试跑。每次结束会显示统计命令，按实际目录执行，例如：

    python3 analyze_diag.py /home/ivanstylish/course-code/lab/intro-exp/results/diag-YYYYMMDD-HHMMSS

## 诊断内容与依赖

- A：read/write × read_lseek/mmap 四种组合，收集 /usr/bin/time -v、strace -c 和可用时的 perf stat 结果。
- B：两个实现的读取模式分别比较裸跑、perf 和 strace 的计时开销。
- C：对 LOAD_API 选定的实现比较安静状态和 stress-ng 背景压力。要完整覆盖两个实现，分别运行一次 LOAD_API=read_lseek 和 LOAD_API=mmap。
- 需要 python3、taskset、/usr/bin/time、strace、stress-ng；perf 不可用时脚本会跳过并留下提示。Ubuntu 可安装前述工具：sudo apt install time strace stress-ng。
- 背景负载部分会启动 stress-ng 并在每次测量后结束；REPS=10 的两种实现运行量较大，先用 REPS=2 检查环境和输出。

原始、未翻译的历史副本仍保存在 Ubuntu：

~/course-code/lab/intro-exp/script-backups/before-simplification-20260928-233854/