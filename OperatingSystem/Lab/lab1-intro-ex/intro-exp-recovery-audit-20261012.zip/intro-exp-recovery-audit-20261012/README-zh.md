# 9 月 28 日 23:28 前版本恢复与实验审核

本材料整理于 2026-10-12。Ubuntu 独立目录为 `~/intro-exp-recovery-audit-20261012`，Windows 独立副本为本目录。课程源代码与恢复脚本自包含在 `course-code/`，运行结果会写到这里的 `course-code/lab/intro-exp/results/`。

## 恢复依据

Ubuntu 的 `course-code` 没有 Git 历史，无法通过 git checkout 回退。找到的保存版本是 `lab/intro-exp/script-backups/before-simplification-20260928-233854`。文件夹创建在 23:38，但五个脚本保留的修改时间为当天 21:15–21:21，早于 23:28。保留的终端记录又显示 21:21:58 的正式系列及 21:26:01 的 A/B/C 诊断，给出了完整主 CSV 和 B 部分原始数值。

- `historical-original/`：五个原脚本逐字节保存，保留历史中文提示，哈希见 `evidence/original-manifest.json`。
- `course-code/lab/intro-exp/`：原版测量逻辑的可运行英文提示副本。只翻译提示/注释并转为 Linux LF 换行；REPS、ITER、TRACE_ITER、A/B/C、stress-ng 参数都保持历史值。两个 C 程序、graph_io.h、graphgen.py 的 SHA-256 全部匹配 9 月 28 日终端记录。
- `evidence/`：来源清单、原终端记录、提示翻译差异、相关 Shell 命令。Shell history 没有时间戳，不能独立证明某次执行时间。
- `data/series-20260928-212158-reconstructed/`：从旧终端完整打印输出恢复的 120 条正式 CSV；不是找回了已丢失的原结果目录。相应逐次日志未找到。
- `data/historical-transcript/tool_overhead.csv`：从终端恢复的旧 B 组 8 条数据。
- `data/` 其他目录：现有运行结果的独立复制，保留原文件名和数据。没有包含误触发的两份不完整 series。
- `analysis/statistics/`：统一离线分析脚本、四组统计、工具开销、背景负载、俄语图表与说明。
- `analysis/timing/`：逐条双时钟核查表及概要。
- `docs/`：代码审核、课程要求复核、俄语实验说明及下一次重复实验计划。

无法凭这些材料保证没有任何从未保存的中间改动；当前恢复的是有文件时间、旧终端记录和哈希核对支持的简化前保存版本。旧 diag-20260928-225235、diag-20260928-212601 的完整目录现已不在原 results 下，只保留终端中打印出来的数值。

## 旧 B 接近 10 分钟的依据

先区分两种命名：正式四组中的 B 通常指 read_lseek/write；诊断脚本的 B 指 bare/strace/perf 工具开销对照。旧正式 read_lseek/write 的 30 次测量累计约 144.77 秒（不含准备），当前同组约 137.84 秒。现有证据支持长时间来自诊断 B 的 strace 项，不能仅凭记忆确认你当时指的是哪一个 B。

旧记录中 read_lseek + strace 的两次时间是 51.671687 和 56.712625 秒，均值 54.192156 秒。旧脚本默认 REPS=10，因此这一项十次就估计约 541.92 秒（9.03 分钟），加上其他组和准备过程接近 10 分钟合理。

这段终端实际执行的是 REPS=2；九分钟是按旧默认十次推算，不能说已经找回十次长测量的 CSV。新版同类单次 strace 的均值约 4.13 秒，两次测量的软件/平台状态无法完整还原，不能把所有变化都归因于脚本。恢复代码不保证恢复当时的运行速度。

旧 C 使用 `stress-ng --cpu 2 --io 1 --vm 1 --vm-bytes 256M`，与新版一个同核 CPU 忙循环不同。旧 C 在压力开始后执行 cp/sync/cat，计时外的准备也可能很久。600s 是 stress-ng 上限，脚本在每次被测运行结束后停止负载。

## 下一次按手册顺序运行

只在 Ubuntu 家目录运行。下面完整历史诊断保留 REPS=10；两次调用覆盖两种实现的 C 对照，同时也会重复 A/B。

```bash
cd ~/intro-exp-recovery-audit-20261012/course-code/lab/intro-exp
CORE=2 BASELINE_SCOPE=full BASELINE_ITER=1 bash prepare_only.sh
CORE=2 ITER=20 TRACE_ITER=1 REPS=10 bash run_full_diagnostics.sh
```

`run_full_diagnostics.sh` 是新加的启动层：探测历史 perf 事件组合是否可用、保存参数与控制台输出，再依次调用 `run_diagnostics_safe.sh`，不减少原 A/B/C 次数。当前 WSL 的 `perf` 命令可能只是找不到匹配内核的包装器；启动层记录探测失败并明确跳过，避免原 B 因为发现命令名而中止。

`run_diagnostics_safe.sh` 是单独的兼容副本：保留历史默认次数、循环顺序、混合负载和计时边界；修复 `top | head` 可能造成的中止，检查负载存活，保存每次程序日志并核对遍历数，记录参数和结束快照。具体差异在 `evidence/safe-diagnostics.diff`。原 `run_diagnostics.sh` 未修改，完整历史字节保存在 `historical-original/`。

兼容副本的 A 中 perf/strace 会把程序输出保存到日志，原版写入 `/dev/null`；这会增加少量日志写入，所以不能声称计时完全相同。B/C 原本就保存程序日志，计时边界保持。实际使用推荐完整启动层，以便探测 perf；不要把它和历史原件混称为逐字节相同。

只想直接使用当时单次脚本时可执行：

```bash
CORE=2 ITER=20 TRACE_ITER=1 REPS=10 LOAD_API=read_lseek bash run_diagnostics.sh
```

此命令的 C 只覆盖 read_lseek。`LOAD_API=mmap` 才覆盖 mmap 的 C。原脚本需要 `mono_time.py`；`analyze_diag.py` 用于可选诊断汇总；graphgen.py 是课程图生成器。无需手工执行计时 helper。

完成 baseline 与诊断后，阅读 `docs/experiment-plan-ru.md`，将实际参数写好并将顶部状态改为 `STATUS: CONFIRMED`。当前保留 DRAFT，没有假装已经确认。本次计划用现有 10 月 11 日系列作下一轮的 pilot，不能倒写成上一轮已事前计算 N 的证明。

如需先观察当前三种时钟，可运行（大约十秒，只有 sleep，没有课程负载）：

```bash
bash ../../../checks/check_clocks.sh results/clock-check.csv
```

正式重复测量：

```bash
CORE=2 N=30 ITER=20 WARMUP=2 bash run_formal.sh
```

`run_formal.sh` 检查计划后调用原 `run_series.sh`；原正式工作量不变。原主脚本每条仍使用 mono_time.py，启动层另外保存整段 realtime/monotonic/monotonic_raw。N=30 是每组 30 次进程运行；ITER=20 是每次运行的工作量，不能算成 600 个独立统计样本。

## 本次审核的重要修正

四组各 30 条都完成，原始数据完整。当前日志另有 5/120 条 realtime 与 monotonic 差超过 0.1 秒，最大差 1.823929337 秒。最明显的记录里 monotonic=1.831976338 秒、realtime=0.008047001 秒，而 user+sys=1.74 秒，支持系统日历时钟发生跳变的解释。单调计时本来就是为避免日历时钟校准而选用；这不是自动判定 mono 数据无效的依据。

不过，用系统日期快照得出的“整段 3分9秒”不能作为独立可靠耗时证明。当前 mono 时间之和为 196.602 秒，realtime 时间之和为 187.671 秒，快照间隔189秒。保留原始数据与全部时钟标记，不删除异常点、不用 realtime 替换 CSV。

现有统计区间表示记录值的随机波动，不能覆盖虚拟化或时钟的系统性误差。正式四组差异方向明确，但小于 1% 的精度声明需要结合平台限制。N 增加无法修复时钟问题。

新的审核已补齐手册中的读/写叠加分布图。Cache 写入计时也不等于全部修改已经同步落盘：课程代码 cached 路径没有强制 fsync/msync，准备 sync 在计时外。

## 离线复算

`analysis/statistics/analyze_existing_data.py` 只读取保存的 CSV 和日志，不执行课程程序；只需要 Python 标准库。图中文字读取 `docs/figure-labels-ru.json`。在资料根目录执行下面命令即可复算本包已保存的 10 月 11 日数据，生成结果仍在 `analysis/statistics/`，不会改写 `data/`：

```bash
cd ~/intro-exp-recovery-audit-20261012
python3 analysis/statistics/analyze_existing_data.py
```

新一轮的正式目录与原版诊断目录可以传入绝对路径，也可以传入相对于资料根目录的路径。原版 B 使用 `tool_overhead.csv`，原版 C 使用 `load.csv`；C 的原始 CSV 没有 `api` 列，所以必须通过 `--load-api` 明确本次 C 实际测量的实现。`--trace-iterations` 必须等于当时的 `TRACE_ITER`，`--load-iterations` 必须等于当时的 `ITER`；下面命令对应上述 `TRACE_ITER=1 ITER=20` 的运行设置。

先把下面的日期时间与 PID 占位内容替换为脚本实际打印的目录名。原正式脚本的目录名只有日期时间，没有 PID；正式数据目录来自 `run_formal.sh` 输出的原 `run_series.sh` 结果路径。诊断启动层的目录下，`diagnostic-directories.csv` 已分别记录 read_lseek 和 mmap 对应的诊断结果路径，不要把启动层目录本身当成含 B/C CSV 的目录。

```bash
cd ~/intro-exp-recovery-audit-20261012
SERIES_DIR="$PWD/course-code/lab/intro-exp/results/series-YYYYMMDD-HHMMSS"
FULL_DIAG_DIR="$PWD/course-code/lab/intro-exp/results/full-diagnostics-YYYYMMDD-HHMMSS-PID"
DIAG_READ_DIR=$(awk -F, '$1=="read_lseek" {print $2; exit}' "$FULL_DIAG_DIR/diagnostic-directories.csv")
DIAG_MMAP_DIR=$(awk -F, '$1=="mmap" {print $2; exit}' "$FULL_DIAG_DIR/diagnostic-directories.csv")

python3 analysis/statistics/analyze_existing_data.py \
  --series "$SERIES_DIR" --diagnostics "$DIAG_READ_DIR" \
  --load-api read_lseek --trace-iterations 1 --load-iterations 20 \
  --output "$PWD/analysis/new-read-lseek"

python3 analysis/statistics/analyze_existing_data.py \
  --series "$SERIES_DIR" --diagnostics "$DIAG_MMAP_DIR" \
  --load-api mmap --trace-iterations 1 --load-iterations 20 \
  --output "$PWD/analysis/new-mmap"
```

这两份分析使用相同的四组正式数据；各自分析对应原版目录中的 B 工具对照，并分别得到 read_lseek 或 mmap 的 C 背景负载结果。两个输出目录互相独立，也不会覆盖本包已审核的统计文件。若直接单独调用了 `run_diagnostics.sh`，将 `--diagnostics` 指向它实际生成的 `diag-*` 目录，并提供那次使用的 `LOAD_API` 即可。

原版 A 没有逐次测量 CSV，分析器只在 `diagnostic-input-notes.json` 中列出实际存在的 A 日志，不合成 A 样本或置信区间。旧 B/C 的 CSV 缺少逐次退出码、节点校验和双时钟字段，这些限制会保留；兼容副本另外保存并验证每次程序日志，应同时查看。缺失的时钟差记为 `null`，不是零。`clock-audit/` 可以审核可用的保存日志，但不能恢复没有保存的时钟记录。默认当前数据的分析结果与原有统计一致；新运行需同时查看其自身日志、参数及诊断限制，不能直接套用本包当前数据的具体数值结论。

## 来源

- https://github.com/secs-dev/os-course/blob/main/lab/intro-exp/README.md
- https://github.com/secs-dev/os-course/blob/main/doc/experiments/environment.md
- https://github.com/secs-dev/os-course/blob/main/doc/experiments/statistics.md
- https://github.com/secs-dev/os-course/blob/main/doc/experiments/monitoring.md
- https://github.com/secs-dev/os-course/blob/main/doc/report.md
- https://docs.python.org/3/library/time.html#time.monotonic

本次只恢复、复制、离线分析与静态检查，未启动课程遍历或 stress-ng。输出文件的来源与新运行数据应保持区分。
