"""Perspective camera and intersections with a triangle mesh (metres)."""

import numpy as np


EPSILON = 1e-6


def dot(a, b):
    return np.einsum("...i,...i->...", a, b)


def unit(v):
    length = np.linalg.norm(v, axis=-1, keepdims=True)
    return np.divide(v, length, out=np.zeros_like(v), where=length > 0)


def camera_rays(camera, x, y, width, height):
    eye = np.asarray(camera["eye"], dtype=float)
    forward = unit(np.asarray(camera["target"], dtype=float) - eye)
    hint = (1, 0, 0) if abs(forward[1]) > 0.99 else (0, 1, 0)
    right = unit(np.cross(forward, hint))
    up = np.cross(right, forward)
    half_height = np.tan(np.deg2rad(camera["fov_y"]) / 2)
    horizontal = ((2 * x / width - 1) * width / height * half_height)[:, None]
    vertical = ((1 - 2 * y / height) * half_height)[:, None]
    directions = unit(forward + horizontal * right + vertical * up)
    return np.broadcast_to(eye, directions.shape), directions


class Mesh:
    def __init__(self, triangles, materials):
        a, b, c = np.asarray(triangles, dtype=float).transpose(1, 0, 2)
        e1, e2 = b - a, c - a
        cross = np.cross(e1, e2)
        if np.any(np.linalg.norm(cross, axis=1) == 0):
            raise ValueError("Сетка содержит вырожденный треугольник")
        self.normals = unit(cross)
        # Affine barycentric coordinates u(P) and v(P) on each triangle plane.
        area2 = dot(cross, self.normals)
        self.u = np.cross(e2, self.normals) / area2[:, None]
        self.v = np.cross(self.normals, e1) / area2[:, None]
        self.offset = dot(a, self.normals)
        self.u_offset = dot(a, self.u)
        self.v_offset = dot(a, self.v)
        self.materials = np.asarray(materials, dtype=int)

    def intersect(self, origin, direction, limit=np.inf):
        """Return closest (distance, triangle index). Misses are (inf, -1)."""
        denominator = np.einsum("ij,kj->ik", direction, self.normals)
        numerator = self.offset - np.einsum("ij,kj->ik", origin, self.normals)
        t = np.divide(numerator, denominator, out=np.zeros_like(numerator),
                      where=np.abs(denominator) > 1e-10)
        limit = np.broadcast_to(limit, (len(origin),))
        ray, tri = np.nonzero((t > EPSILON) & (t < limit[:, None]))
        points = origin[ray] + t[ray, tri, None] * direction[ray]
        u = dot(points, self.u[tri]) - self.u_offset[tri]
        v = dot(points, self.v[tri]) - self.v_offset[tri]
        inside = (u >= -1e-10) & (v >= -1e-10) & (u + v <= 1 + 1e-10)
        distances = np.full_like(t, np.inf)
        distances[ray[inside], tri[inside]] = t[ray[inside], tri[inside]]
        nearest = distances.argmin(axis=1)
        depth = distances[np.arange(len(origin)), nearest]
        return depth, np.where(np.isfinite(depth), nearest, -1)
