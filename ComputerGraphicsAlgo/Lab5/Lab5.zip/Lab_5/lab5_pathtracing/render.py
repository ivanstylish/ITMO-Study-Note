"""Linear RGB path tracing with explicit point-light connections."""

import numpy as np

from geometry import EPSILON, camera_rays, dot, unit


def fresnel(cos_i, ior):
    """Energy reflectance for unpolarized light from air into a dielectric."""
    cos_t = np.sqrt(1 - (1 - cos_i**2) / ior**2)
    s = (cos_i - ior * cos_t) / (cos_i + ior * cos_t)
    p = (cos_t - ior * cos_i) / (cos_t + ior * cos_i)
    return (s**2 + p**2) / 2


def brdf(scene, material, normal, wi, wo):
    """Lambert and Cook–Torrance (3281, equations 3.4.5.1 and 3.4.5.9)."""
    ni, no = dot(normal, wi), dot(normal, wo)
    same_side = (ni > 0) & (no > 0)
    result = scene.kd[material] / np.pi
    result[~same_side] = 0
    glossy = same_side & np.any(scene.ks[material] > 0, axis=1)
    h = unit((wi + wo)[glossy])
    nh = np.clip(dot(normal[glossy], h), 1e-10, 1)
    oh = np.clip(dot(wo[glossy], h), 1e-10, 1)
    alpha2 = scene.roughness[material[glossy]]**2
    tan2 = (1 - nh**2) / nh**2
    distribution = np.exp(-tan2 / alpha2) / (np.pi * alpha2 * nh**4)
    geometry = np.minimum(1, 2 * nh * np.minimum(ni[glossy], no[glossy]) / oh)
    reflection = fresnel(oh, scene.ior[material[glossy]])
    specular = distribution * geometry * reflection / (4 * ni[glossy] * no[glossy])
    result[glossy] += scene.ks[material[glossy]] * specular[:, None]
    return result


def point_irradiance(light, position, normal):
    delta = light.position - position
    distance = np.linalg.norm(delta, axis=1)
    wi = unit(delta)
    emission = np.maximum(dot(-wi, light.axis), 0)
    reception = np.maximum(dot(wi, normal), 0)
    falloff = np.divide(emission * reception, distance**2,
                        out=np.zeros_like(distance), where=distance > EPSILON)
    return wi, distance, falloff[:, None] * light.intensity


def local_radiance(scene, position, normal, wo, material):
    result = np.zeros_like(position)
    origin = position + EPSILON * normal
    for light in scene.lights:
        wi, _, irradiance = point_irradiance(light, position, normal)
        lit = np.flatnonzero(np.any(irradiance > 0, axis=1))
        shadow_delta = light.position - origin[lit]
        shadow_end = np.linalg.norm(shadow_delta, axis=1)
        _, blocker = scene.mesh.intersect(origin[lit], unit(shadow_delta), shadow_end - EPSILON)
        lit = lit[blocker == -1]
        factor = brdf(scene, material[lit], normal[lit], wi[lit], wo[lit])
        result[lit] += factor * irradiance[lit]
    return result


def cosine_direction(normal, u, v):
    """Cosine hemisphere PDF p(wi) = cos(theta)/pi, per unit solid angle."""
    z = np.sqrt(1 - u)
    radius = np.sqrt(u)
    phi = 2 * np.pi * v
    hint = np.zeros_like(normal)
    hint[:, 0] = np.abs(normal[:, 1]) > 0.99
    hint[:, 1] = 1 - hint[:, 0]
    tangent = unit(np.cross(hint, normal))
    bitangent = np.cross(normal, tangent)
    return (tangent * (radius * np.cos(phi))[:, None]
            + bitangent * (radius * np.sin(phi))[:, None] + normal * z[:, None])


def trace(scene, origins, directions, random):
    count = len(origins)
    active = np.arange(count)
    throughput = np.ones((count, 3))
    primary = np.zeros((count, 3))
    indirect = np.zeros_like(primary)
    depth = random.shape[1] + 1

    for bounce in range(depth):
        distance, triangles = scene.mesh.intersect(origins, directions)
        hits = triangles >= 0
        active, triangles = active[hits], triangles[hits]
        if len(active) == 0:
            break
        rays = directions[hits]
        position = origins[hits] + distance[hits, None] * rays
        normal = scene.mesh.normals[triangles]
        wo = -rays
        normal = np.where((dot(normal, wo) < 0)[:, None], -normal, normal)
        material = scene.mesh.materials[triangles]
        contribution = throughput[active] * local_radiance(scene, position, normal, wo, material)
        if bounce == 0:
            primary[active] = contribution
        else:
            indirect[active] += contribution
        if bounce + 1 == depth:
            break
        u, v = random[active, bounce].T
        directions = cosine_direction(normal, u, v)
        # f_r * cos(theta) / p(wi) reduces to pi * f_r for this PDF.
        throughput[active] *= np.pi * brdf(scene, material, normal, directions, wo)
        origins = position + EPSILON * normal
    return primary, indirect


def render(scene, camera, size, samples, depth, seed, progress=None):
    rng = np.random.default_rng(seed)
    direct = np.empty((size * size, 3))
    indirect = np.empty_like(direct)
    # Generate jitter and path variates together so camera samples stay fixed
    # when comparing the paired primary and full images.
    batch_size = min(1024, max(1, 8192 // samples))
    for start in range(0, size * size, batch_size):
        stop = min(start + batch_size, size * size)
        y, x = np.divmod(np.arange(start, stop), size)
        draws = rng.random((len(x), samples, depth, 2))
        image_jitter = draws[:, :, 0]
        if (strata := int(np.sqrt(samples)))**2 == samples:
            sy, sx = np.divmod(np.arange(samples), strata)
            image_jitter = (image_jitter + np.stack((sx, sy), axis=1)) / strata
        px = (x[:, None] + image_jitter[:, :, 0]).ravel()
        py = (y[:, None] + image_jitter[:, :, 1]).ravel()
        origins, directions = camera_rays(camera, px, py, size, size)
        path_random = draws[:, :, 1:].reshape(len(px), depth - 1, 2)
        first, rest = trace(scene, origins, directions, path_random)
        direct[start:stop] = first.reshape(-1, samples, 3).mean(axis=1)
        indirect[start:stop] = rest.reshape(-1, samples, 3).mean(axis=1)
        if progress is not None:
            progress(stop / (size * size))
    return direct.reshape(size, size, 3), indirect.reshape(size, size, 3)
